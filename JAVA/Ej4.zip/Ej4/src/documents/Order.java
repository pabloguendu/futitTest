package documents;

public class Order extends Document{
    @Override
    public String toString() {
        return "Order for you";
    }
}
