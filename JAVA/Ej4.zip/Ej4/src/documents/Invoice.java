package documents;

public class Invoice extends Document {
    @Override
    public String toString() {
        return "Invoice for you";
    }

}
