package documents.HumanResource;

import documents.Document;

public class Contract extends Document {
    @Override
    public String toString() {
        return "Contract for you";
    }
}
