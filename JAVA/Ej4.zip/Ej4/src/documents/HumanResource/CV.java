package documents.HumanResource;
import documents.Document;

public class CV extends Document {
    @Override
    public String toString() {
        return "CV for you";
    }

}
