package documents;

public class UrgentOrder extends Order {
    @Override
    public String toString() {
        return "UrgentOrder for you";
    }

}
