package documents;


public abstract class Document {

    @Override
    public String toString() {
        return super.toString();
    }
}


